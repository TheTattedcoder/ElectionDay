#include "TallyVotes.h"

TallyVotes::TallyVotes()
{
}

TallyVotes::~TallyVotes()
{
}

string TallyVotes::eliminateLosers()
{
  return "zork";
} // string TallyVotes::eliminateLosers()

string TallyVotes::getWinner()
{
  string s = "";

  return s;
} // string TallyVotes::getWinner() const

void TallyVotes::initialize(Scanner& inStream)
{
} // void TallyVotes::initialize(Scanner& inStream)

void TallyVotes::tallyVotes(ofstream& outStream)
{
} // void TallyVotes::tallyVotes(ofstream& outStream)

bool TallyVotes::weHaveAWinner()
{
  bool thereIsAWinner = false;

  return thereIsAWinner;
} // string TallyVotes::weHaveAWinner()

string TallyVotes::toString() const
{
  string s = "";

  return s;
} // string TallyVotes::toString() const

string TallyVotes::toStringCandidates() const
{
  string s = "";
  return s;
} // string TallyVotes::toStringCandidates()

string TallyVotes::toStringVotes() const
{
  string s = "";

  return s;
} // string TallyVotes::toStringCandidates()
