#include "Candidate.h"

Candidate::Candidate()
{
}

Candidate::~Candidate()
{
}

string Candidate::toString() const
{
  string s = "";

  return s;
} // string Candidate::toString() const
